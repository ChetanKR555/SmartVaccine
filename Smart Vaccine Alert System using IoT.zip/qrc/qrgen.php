<!--Project name:Smart vaccine alert system using IoT
Author list:Amrutha M V, Arpitha J A,Bindu N L,Marella Jessica
File name:qrgen.php
-->
<?php 

    include('qrlib.php'); 
    include('firestore.php');
    //include('f1.php');
date_default_timezone_set('Asia/Calcutta');
//mysql_connect("localhost","jnnceac_chetan","fedora12345");
//mysql_select_db("jnnceac_site");

    // how to save PNG codes to server 
     
  
     /*$vid=$_POST['t1'];
     $vname=$_POST['t2'];
     $m_date=$_POST['t3'];
     $e_date=$_POST['t4'];
     $cost=$_POST['t5'];
     $vendor=$_POST['t6'];
     $dosage=$_POST['t7'];
     $temp=$_POST['t8'];
     //$qty=$_POST['t9'];*/
    
     //$sdate = mysql_real_escape_string($sdate);
     $m_date = date('Y-m-d', strtotime(str_replace('-', '/', $m_date)));
     
     //$tdate = mysql_real_escape_string($tdate);
     $e_date = date('Y-m-d', strtotime(str_replace('-', '/', $e_date)));
     
     if (!file_exists("$vid")) {
    mkdir("$vid", 0777, true);
      }
      
      /*if (!file_exists("$vid/$vname")) {
    mkdir("$vid/$vname", 0777, true);
      }
      
      if (!file_exists("$vid/$vname/$vendor")) {
    mkdir("$vid/$vname/$vendor", 0777, true);
      }*/
      
      
     //for($i=1;$i<=$qty;$i++)
     //{
        $objectid = md5("$vid"); 
         // we need to generate filename somehow,  
    // with md5 or with database ID used to obtains $codeContents... 
        $fileName =  $objectid.'.png'; 
        echo $fileName;
     
    //$pngAbsoluteFilePath = $tempDir.$fileName; 
    $urlRelativeFilePath = "$vid/".$fileName; 
     
    // generating 
    if (!file_exists( $urlRelativeFilePath )) { 
        QRcode::png($objectid,  $urlRelativeFilePath, QR_ECLEVEL_L, 2); 
        echo 'File generated!'; 
        echo '<hr/>'; 
       
         
        
    } else { 
        echo 'File already generated! We can use this cached file to speed up site on common codes!'; 
        echo '<hr />'; 
    } 
     
   // echo 'Server PNG File: '. $urlRelativeFilePath ; 
    //echo '<hr />'; 
     //}  
    // displaying 
    //echo '<img src="'. $urlRelativeFilePath.'" />'; 
    
    ?>