<!--Project name:Smart vaccine alert system using IoT
Author list:Amrutha M V, Arpitha J A,Bindu N L,Marella Jessica
File name:ft.php
Functions:None-->
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include('firestore.php');
use PHPFireStore\FireStoreApiClient;
use PHPFireStore\FireStoreDocument;
$firestore = new FireStoreApiClient(
 'vaccines-18ae8', 'AIzaSYAor9pOIj9NVwOos4WY2VA-EafrbSW6awM'
);

$document = new FireStoreDocument();
$qrcode=$_POST['qrcode'];


// Create or update document people/me
//$firestore->addDocument('sps', $document);

$d=($firestore->getDocument('vaccines', $qrcode));
$json=$d->toJson();
echo $json;


?>

