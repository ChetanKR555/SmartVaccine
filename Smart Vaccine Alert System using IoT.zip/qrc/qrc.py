#Project name:Smart vaccine alert system using IoT
#Author list:Amrutha M V, Arpitha J A,Bindu N L,Marella Jessica
#File name:front.html
#Functions:None
#Global Variables:None
# import the necessary packages
from imutils.video import VideoStream
from pyzbar import pyzbar
import argparse
import datetime
import imutils
import time
import cv2
import requests
import json
import os
import glob
import time
from datetime import datetime
import serial
import RPi.GPIO as GPIO      
import os, time

# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-o", "--output", type=str, default="barcodes.csv",
	help="path to output CSV file containing barcodes")
args = vars(ap.parse_args())


# Initialize the GPIO Pins
os.system('modprobe w1-gpio')  # Turns on the GPIO module
os.system('modprobe w1-therm') # Turns on the Temperature module
 
# Finds the correct device file that holds the temperature data
base_dir = '/sys/bus/w1/devices/'
device_folder = glob.glob(base_dir + '28*')[0]
device_file = device_folder + '/w1_slave'
 
# A function that reads the sensors data
#Function name:read_temp_raw()
#Input:None
#Output:Opens the temperature device file and returns the text
#Logic:Reads the input data
def read_temp_raw():
  f = open(device_file, 'r') # Opens the temperature device file
  lines = f.readlines() # Returns the text
  f.close()
  return lines

#Function name:sim()
#Input:It takes message and phone number as input
#Output:Sends the message or the alert to the particular authorized user
#Logic:Enables serial communication and sends the message to a particular number
def sim(mes,pno):
		  GPIO.setmode(GPIO.BOARD)    
     
                  # Enable Serial Communication
		  port = serial.Serial("/dev/ttyS0", baudrate=9600, timeout=1)
                   
                  # Transmitting AT Commands to the Modem
                  # '\r\n' indicates the Enter key
                   
		  port.write(('AT'+'\r\n').encode())
		  rcv = port.read(10)
		  print(rcv)
		  time.sleep(1)
		   
		  port.write(('ATE0'+'\r\n').encode())      # Disable the Echo
		  rcv = port.read(10)
		  print(rcv)
		  time.sleep(1)
		   
		  port.write(('AT+CMGF=1'+'\r\n').encode())  # Select Message format as Text mode 
		  rcv = port.read(10)
		  print(rcv)
		  time.sleep(1)

		  port.write(('AT+CNMI=2,1,0,0,0'+'\r\n').encode())   # New SMS Message Indications
		  rcv = port.read(10)
		  print(rcv)
		  time.sleep(1)
		   
		  # Sending a message to a particular Number
		   
		  port.write(('AT+CMGS="'+pno+'"'+'\r\n').encode())
		  rcv = port.read(10)
		  print(rcv)
		  time.sleep(1)
		   
		  port.write((mes+'\r\n').encode())  # Message
		  rcv = port.read(10)
		  print(rcv)
		   
		  port.write(("\x1A").encode()) # Enable to send SMS
		  for i in range(10):
		      rcv = port.read(10)
		      print(rcv)
 
# Convert the value of the sensor into a temperature

#Function name:read_temp()
#Input:None
#Output:It gives the temperature in celsius and farenheit
#Logic:Read the temperature 'device file' and Look for the position of the '=' in the second line of the device file.

def read_temp():
  lines = read_temp_raw() # Read the temperature 'device file'
 
  # While the first line does not contain 'YES', wait for 0.2s
  # and then read the device file again.
  while lines[0].strip()[-3:] != 'YES':
    time.sleep(0.2)
    lines = read_temp_raw()
 
  # Look for the position of the '=' in the second line of the
  # device file.
  equals_pos = lines[1].find('t=')
 
  # If the '=' is found, convert the rest of the line after the
  # '=' into degrees Celsius, then degrees Fahrenheit
  if equals_pos != -1:
    temp_string = lines[1][equals_pos+2:]
    temp_c = float(temp_string) / 1000.0
    temp_f = temp_c * 9.0 / 5.0 + 32.0
    return temp_c, temp_f
 
# Print out the temperature until the pr

# initialize the video stream and allow the camera sensor to warm up
print("[INFO] starting video stream...")
vs = VideoStream(src=0).start()
#vs = VideoStream(usePiCamera=True).start()
time.sleep(2.0)
 
# open the output CSV file for writing and initialize the set of
# barcodes found thus far
csv = open(args["output"], "w")
found = set()




# loop over the frames from the video stream
flag=True

 
# close the output CSV file do a bit of cleanup
#print("[INFO] cleaning up...")
#csv.close()
#cv2.destroyAllWindows()
#vs.stop()
                
while flag:
	# grab the frame from the threaded video stream and resize it to
	# have a maximum width of 400 pixels
	frame = vs.read()
	frame = imutils.resize(frame, width=300)
 
	# find the barcodes in the frame and decode each of the barcodes
	barcodes = pyzbar.decode(frame)
	# loop over the detected barcodes
	for barcode in barcodes:
		# extract the bounding box location of the barcode and draw
		# the bounding box surrounding the barcode on the image
		(x, y, w, h) = barcode.rect
		cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
 
		# the barcode data is a bytes object so if we want to draw it
		# on our output image we need to convert it to a string first
		barcodeData = barcode.data.decode("utf-8")
		barcodeType = barcode.type
		csv.close()
		cv2.destroyAllWindows()
		vs.stop()

 
		# draw the barcode data and barcode type on the image
		text = "{}".format(barcodeData)
		print(text)
		URL = "http://localhost/vaccine/ft.php"
		PARAMS = {'qrcode':text}
		r = requests.post(url = URL, data = PARAMS)
		x=r.text
		#print(x)
		
		y=json.loads(x)
		print("VID:",y['fields']['vid']['stringValue'])
		print("Vname:",y['fields']['vname']['stringValue'])
		print("Exp Date:",y['fields']['e_date']['stringValue'])
		print("Mfg Date:",y['fields']['m_date']['stringValue'])
		print("Min-Temp:",y['fields']['temp1']['stringValue'])
		print("MaxTemp:",y['fields']['temp2']['stringValue'])
		print("Vendor:",y['fields']['vendor']['stringValue'])
		print("Cost:",y['fields']['cost']['stringValue'])
		print("Dosage:",y['fields']['dosage']['stringValue'])
		temp1=y['fields']['temp1']['stringValue']
		temp2=y['fields']['temp2']['stringValue']
		e_date=y['fields']['e_date']['stringValue']
		


		
                #print(y['fields']['OT']['stringValue'])
		cnt=0
		tmp=False
		while (cnt<10):
			cnt=cnt+1
			tmp=read_temp()
		print("Vaccine temperature is:")
		print(tmp)
		flag=False
		if(tmp[0]<float(temp1) or tmp[0]>float(temp2)):
		  sim('operating temp issue','9916597534')
		  #print('Operating temperature limit failed')
		  #cdate=datetime.now()
		  #cdf = cdate. strftime("%Y-%m-%d")
		  #if cdf>e_date:
		   # print('expired')
		 # else:
		   # print('not expired')
		  
		else:
		  print('check expiry')
		  cdate=datetime.now()
		  cdf = cdate.strftime("%Y-%m-%d")
		  if cdf>e_date:
		      sim('vaccine expired','9916597534')
		      #print('expired')
		      
		  else:
		    sim('Vaccine is safe to use','9916597534')
		  
		  
		
		break
	        #if (tmp>=tem1 && tmp<=temp2):
		#							print('valid')
		#else:
		#							print('invalid')
		#d=datetime.datetime.today()
		#if (d.strftime('%d-%m-%Y'))>e_date:
		#							print('Invalid')
		#else:
		#print("valid date")
		cv2.putText(frame, text, (x, y - 10),
			cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
 
		# if the barcode text is currently not in our CSV file, write
		# the timestamp + barcode to disk and update the set
		if barcodeData not in found:
			csv.write("{},{}\n".format(datetime.datetime.now(),
				barcodeData))
			csv.flush()
			found.add(barcodeData)

			# show the output frame
	cv2.imshow("Barcode Scanner", frame)
	key = cv2.waitKey(1) & 0xFF
 
	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
		break
# close the output CSV file do a bit of cleanup
print("[INFO] cleaning up...")
csv.close()
cv2.destroyAllWindows()
vs.stop()
