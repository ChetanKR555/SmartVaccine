<!--Project name:Smart vaccine alert system using IoT
Author list:Amrutha M V, Arpitha J A,Bindu N L,Marella Jessica
File name:f1.php
Functions:None-->
<?php
include('firestore.php');
include('qrlib.php'); 
    //include('firestore.php');
    //include('f1.php');
date_default_timezone_set('Asia/Calcutta');
//include('qrc/qrgen.php');
use PHPFireStore\FireStoreApiClient;
use PHPFireStore\FireStoreDocument;
$firestore = new FireStoreApiClient(
 'vaccines-18ae8', 'AIzaSyAor9pOIj9NVwOos4WY2VA-EafrbSW6awM'
);
$vid=$_POST['vid'];
$vname=$_POST['vname'];
$m_date=$_POST['m_date'];
$e_date=$_POST['e_date'];
$cost=$_POST['cost'];
$vendor=$_POST['vendor'];
$dosage=$_POST['dosage'];
$temp1=$_POST['temp1'];
$temp2=$_POST['temp2'];

$document = new FireStoreDocument();
$document->setString('vid', $vid);
$document->setString('vname', $vname);
$document->setString('m_date',$m_date);
$document->setString('e_date', $e_date);
$document->setString('cost', $cost);
$document->setString('vendor', $vendor);
$document->setString('dosage', $dosage);
$document->setString('temp1',$temp1);
$document->setString('temp2',$temp2);
// Create or update document people/me
//$firestore->addDocument('vaccines', $document);

 //$sdate = mysql_real_escape_string($sdate);
     $m_date = date('Y-m-d', strtotime(str_replace('-', '/', $m_date)));
     
     //$tdate = mysql_real_escape_string($tdate);
     $e_date = date('Y-m-d', strtotime(str_replace('-', '/', $e_date)));
     
     if (!file_exists("$vid")) {
    mkdir("$vid", 0777, true);
      }
      
      /*if (!file_exists("$vid/$vname")) {
    mkdir("$vid/$vname", 0777, true);
      }
      
      if (!file_exists("$vid/$vname/$vendor")) {
    mkdir("$vid/$vname/$vendor", 0777, true);
      }*/
      
      
     //for($i=1;$i<=$qty;$i++)
     //{
        $objectid = md5("$vid"); 
         // we need to generate filename somehow,  
    // with md5 or with database ID used to obtains $codeContents... 
        $fileName =  $objectid.'.png'; 
        echo $fileName;
     
    //$pngAbsoluteFilePath = $tempDir.$fileName; 
    $urlRelativeFilePath = "$vid/".$fileName; 
     
    // generating 
    if (!file_exists( $urlRelativeFilePath )) { 
        QRcode::png($objectid,$urlRelativeFilePath,QR_ECLEVEL_L,4); 
        echo 'File generated!'; 
        echo '<hr/>'; 
       /* $sq = mysql_query("select * from qrobject where objectid='$objectid'");
         if($row=mysql_fetch_array($sq))
         {
          echo "QRCode Already geneated";
          exit(0);
         }
         else
         {
             mysql_query("insert into qrobject values('$college','$dept','$objecttype','$objectid',$i,'$sname','$sdate','$make','$spec','$tdate')");
             echo "insert into qrobject values('$college','$dept','$objecttype','$objectid','$sname','$sdate','$make','$spec',$qty,'$tdate')";
         }*/
         
        
    } 
    else { 
        echo 'File already generated! We can use this cached file to speed up site on common codes!'; 
        echo '<hr />'; 
    } 
     
   // echo 'Server PNG File: '. $urlRelativeFilePath ; 
    //echo '<hr />'; 
     //}  
    // displaying 
    //echo '<img src="'. $urlRelativeFilePath.'" />'; 
    

//{
if(isset($_POST['add']))
{

 $res=$firestore->updateDocument('vaccines',$objectid, $document, false);
 if(preg_match("/Document already exists/",$res))
 {
    $firestore->updateDocument('vaccines',$objectid, $document, true);
    echo "updated";
 }
 else
 {
 	echo "inserted";
 }

}

//$firestore->deleteDocument('vaccines','ZBi41jHevdOFlQ5lJEFA');

if (isset($_POST['delete'])) {


	$firestore->deleteDocument('vaccines',$vid);
	echo "deleted";

}
//false-new true-old
//$d=($firestore->getDocument('sps', 'prod2'));
//echo $d->get("vname")["stringValue"];
//echo $d->$pname;


// Fetch the document people/me
//$firestore->getDocument('people', 'me');
// Remove the document people/me
//$firestore->deleteDocument('sps',$vid);
// Add this new document in people collection, 
// but let Firestore give it the document id
//$firestore->addDocument('people', $document);
// Create this document, fail if it already exists
//$firestore->updateDocument('people', 'me', $document, false);
// Update this document, fail if it does not exist
//$firestore->updateDocument('people', 'me', $document, true);

?>